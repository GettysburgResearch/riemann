# X-18506 — Growing source-canonical D-0001 direct blocks

This experiment generalises `X-18505` from one fitted `N=1` column to the exact
source decomposition at every finite even level.

## Exact coordinates

```text
basis     [e0,e-1+e1,...,e-N+eN]
metric    diag(1,2,...,2)
Q_W       (1,...,1)^T
Q_E[:,k]  -2 e0 + e_(k+1)
G_W       1+2N
G_E       2 I + 4 11^T
```

`Q_E` spans the exact source-valid hyperplane `f(0)=0`; `Q_W` is its metric
orthogonal source-corrector quotient.  No numerical eigenspace is used to define
the packet.

For every level the producer includes every prime power `q<=c`, all cutoff-free
pole/archimedean terms, and emits the complete immutable objects

```text
Q_W P_W E_W Z_W C X_N R_N G_W.
```

The exact consumer proves `C-h G_E>0` by interval LDL and then evaluates the
unchanged direct-shorting matrix

```text
D_N = B_W-2 Z_W^* X_N+X_N^* C X_N
      -h^-1 R_N^* G_E^-1 R_N.
```

It accepts a level only if

```text
D_N-m G_W > 0,
```

which is exactly `Delta_(c,N)=0` for the emitted lower matrix.

## Ladder

```text
(10,2) (20,3) (50,4) (100,5) (200,6)
(500,7) (1000,8) (2000,9) (5000,10)
```

The dyadic trial solves and coercivity targets were frozen from independent
140-digit reconnaissance.  The producer runs at 384 and 512 Arb bits and the
higher-precision certificate must be contained in the lower-precision one.

## Replay

```bash
python -m pip install python-flint==0.9.0
python arb_producer.py config.json --precision-bits 384 --output artifacts/p384.json
python verify.py artifacts/p384.json --output artifacts/v384.json
python arb_producer.py config.json --precision-bits 512 --output artifacts/p512.json
python verify.py artifacts/p512.json --output artifacts/v512.json
python compare_precisions.py artifacts/p384.json artifacts/p512.json \
  --output artifacts/precision-comparison.json
PYTHONPATH=. python -m unittest -v tests/test_verify.py
```

## Scope

A successful artifact closes a real finite growing ladder.  It does not convert
nine levels into an unbounded theorem.  The exact remaining scaling statement is
a uniform lower bound for the source-corrector Schur scalar on one unbounded
schedule, together with source-valid coercivity at every retained level.
