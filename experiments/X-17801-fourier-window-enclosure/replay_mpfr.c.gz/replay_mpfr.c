#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include "mpfr_min.h"

typedef struct { mpfr_t re, im, r; } ball;
typedef struct { mpfr_t t[24], eps; } ctx;
typedef struct { int n,p; mpfr_t wc,wr,lc,lr; } event;
static const mpfr_prec_t PREC=256;
static void mi(mpfr_t x){mpfr_init2(x,PREC);} 
static void ball_init(ball *z){mi(z->re);mi(z->im);mi(z->r);mpfr_set_ui(z->re,0,MPFR_RNDN);mpfr_set_ui(z->im,0,MPFR_RNDN);mpfr_set_ui(z->r,0,MPFR_RNDU);} 
static void ball_clear(ball*z){mpfr_clear(z->re);mpfr_clear(z->im);mpfr_clear(z->r);} 
static void ball_copy(ball*z,const ball*a){mpfr_set(z->re,a->re,MPFR_RNDN);mpfr_set(z->im,a->im,MPFR_RNDN);mpfr_set(z->r,a->r,MPFR_RNDU);} 
static void ctx_init(ctx*c){for(int i=0;i<24;i++)mi(c->t[i]);mi(c->eps);mpfr_set_ui(c->eps,1,MPFR_RNDN);mpfr_mul_2si(c->eps,c->eps,-220,MPFR_RNDN);} 
static void ctx_clear(ctx*c){for(int i=0;i<24;i++)mpfr_clear(c->t[i]);mpfr_clear(c->eps);} 
static void mag1(mpfr_t z,const ball*a,ctx*c){mpfr_abs(c->t[20],a->re,MPFR_RNDU);mpfr_abs(c->t[21],a->im,MPFR_RNDU);mpfr_add(z,c->t[20],c->t[21],MPFR_RNDU);mpfr_add(z,z,a->r,MPFR_RNDU);} 
static void ball_add(ball*z,const ball*a,const ball*b,int sub,ctx*c){
 if(sub){mpfr_sub(z->re,a->re,b->re,MPFR_RNDN);mpfr_sub(z->im,a->im,b->im,MPFR_RNDN);}else{mpfr_add(z->re,a->re,b->re,MPFR_RNDN);mpfr_add(z->im,a->im,b->im,MPFR_RNDN);} 
 mag1(c->t[0],a,c);mag1(c->t[1],b,c);mpfr_add(z->r,a->r,b->r,MPFR_RNDU);mpfr_add(c->t[2],c->t[0],c->t[1],MPFR_RNDU);mpfr_add_ui(c->t[2],c->t[2],1,MPFR_RNDU);mpfr_mul(c->t[2],c->t[2],c->eps,MPFR_RNDU);mpfr_add(z->r,z->r,c->t[2],MPFR_RNDU);
}
static void ball_mul(ball*z,const ball*a,const ball*b,ctx*c){
 mpfr_mul(c->t[0],a->re,b->re,MPFR_RNDN);mpfr_mul(c->t[1],a->im,b->im,MPFR_RNDN);mpfr_sub(z->re,c->t[0],c->t[1],MPFR_RNDN);
 mpfr_mul(c->t[0],a->re,b->im,MPFR_RNDN);mpfr_mul(c->t[1],a->im,b->re,MPFR_RNDN);mpfr_add(z->im,c->t[0],c->t[1],MPFR_RNDN);
 mag1(c->t[2],a,c);mag1(c->t[3],b,c);
 mpfr_mul(z->r,c->t[2],b->r,MPFR_RNDU);mpfr_mul(c->t[4],c->t[3],a->r,MPFR_RNDU);mpfr_add(z->r,z->r,c->t[4],MPFR_RNDU);mpfr_mul(c->t[4],a->r,b->r,MPFR_RNDU);mpfr_add(z->r,z->r,c->t[4],MPFR_RNDU);
 mpfr_mul(c->t[4],c->t[2],c->t[3],MPFR_RNDU);mpfr_add_ui(c->t[4],c->t[4],1,MPFR_RNDU);mpfr_mul(c->t[4],c->t[4],c->eps,MPFR_RNDU);mpfr_add(z->r,z->r,c->t[4],MPFR_RNDU);
}
static void ball_scale2(ball*z,long e){mpfr_mul_2si(z->re,z->re,e,MPFR_RNDN);mpfr_mul_2si(z->im,z->im,e,MPFR_RNDN);mpfr_mul_2si(z->r,z->r,e,MPFR_RNDU);} 
static void ball_from_rect(ball*z,mpfr_srcptr rlo,mpfr_srcptr rhi,mpfr_srcptr ilo,mpfr_srcptr ihi,ctx*c){
 mpfr_add(z->re,rlo,rhi,MPFR_RNDN);mpfr_div_2si(z->re,z->re,1,MPFR_RNDN);mpfr_add(z->im,ilo,ihi,MPFR_RNDN);mpfr_div_2si(z->im,z->im,1,MPFR_RNDN);
 mpfr_sub(c->t[0],rhi,rlo,MPFR_RNDU);mpfr_div_2si(c->t[0],c->t[0],1,MPFR_RNDU);mpfr_sub(c->t[1],ihi,ilo,MPFR_RNDU);mpfr_div_2si(c->t[1],c->t[1],1,MPFR_RNDU);mpfr_add(z->r,c->t[0],c->t[1],MPFR_RNDU);mpfr_add(z->r,z->r,c->eps,MPFR_RNDU);
}
static void fft(ball*a,size_t n,int inverse,ball*wlen,ctx*c){
 for(size_t i=1,j=0;i<n;i++){size_t bit=n>>1;for(;j&bit;bit>>=1)j^=bit;j^=bit;if(i<j){ball tmp=a[i];a[i]=a[j];a[j]=tmp;}}
 ball u,v,w,tmp;ball_init(&u);ball_init(&v);ball_init(&w);ball_init(&tmp);int stage=0;
 for(size_t len=2;len<=n;len<<=1,stage++){
  ball wl;ball_init(&wl);ball_copy(&wl,&wlen[stage]);if(!inverse)mpfr_neg(wl.im,wl.im,MPFR_RNDN);
  for(size_t i=0;i<n;i+=len){mpfr_set_ui(w.re,1,MPFR_RNDN);mpfr_set_ui(w.im,0,MPFR_RNDN);mpfr_set_ui(w.r,0,MPFR_RNDU);for(size_t j=0;j<len/2;j++){
    ball_copy(&u,&a[i+j]);ball_mul(&v,&a[i+j+len/2],&w,c);ball_add(&a[i+j],&u,&v,0,c);ball_add(&a[i+j+len/2],&u,&v,1,c);ball_mul(&tmp,&w,&wl,c);ball_copy(&w,&tmp);
  }}ball_clear(&wl);
 }
 if(inverse){int e=0;size_t m=n;while(m>1){e--;m>>=1;}for(size_t i=0;i<n;i++)ball_scale2(&a[i],e);}ball_clear(&u);ball_clear(&v);ball_clear(&w);ball_clear(&tmp);
}
static uint8_t*sieve(int lim){uint8_t*a=malloc((size_t)lim+1);memset(a,1,(size_t)lim+1);a[0]=a[1]=0;for(int p=2;(long long)p*p<=lim;p++)if(a[p])for(long long v=(long long)p*p;v<=lim;v+=p)a[v]=0;return a;}
static int cmp_event(const void*A,const void*B){int a=((event*)A)->n,b=((event*)B)->n;return(a>b)-(a<b);} 
static void event_init(event*e){mi(e->wc);mi(e->wr);mi(e->lc);mi(e->lr);} 
static void event_clear(event*e){mpfr_clear(e->wc);mpfr_clear(e->wr);mpfr_clear(e->lc);mpfr_clear(e->lr);} 
static void midpoint_radius(mpfr_t c0,mpfr_t r0,mpfr_srcptr lo,mpfr_srcptr hi,ctx*x){mpfr_add(c0,lo,hi,MPFR_RNDN);mpfr_div_2si(c0,c0,1,MPFR_RNDN);mpfr_sub(x->t[22],c0,lo,MPFR_RNDU);mpfr_sub(x->t[23],hi,c0,MPFR_RNDU);if(mpfr_cmp(x->t[22],x->t[23])>0)mpfr_set(r0,x->t[22],MPFR_RNDU);else mpfr_set(r0,x->t[23],MPFR_RNDU);} 
static void printv(const char*n,mpfr_srcptr x){printf("%s=",n);mpfr_printf("%.50Rg\n",x);} 

/* Coefficient rectangles use simple MPFR outward operations. */
typedef struct {mpfr_t lo,hi;} iv; static void ii(iv*x){mi(x->lo);mi(x->hi);}static void ic(iv*x){mpfr_clear(x->lo);mpfr_clear(x->hi);}static void setu(iv*x,unsigned long n){mpfr_set_ui(x->lo,n,MPFR_RNDD);mpfr_set_ui(x->hi,n,MPFR_RNDU);}static void sets(iv*x,const char*s){mpfr_set_str(x->lo,s,10,MPFR_RNDD);mpfr_set_str(x->hi,s,10,MPFR_RNDU);}static void addi(iv*z,const iv*a,const iv*b){mpfr_add(z->lo,a->lo,b->lo,MPFR_RNDD);mpfr_add(z->hi,a->hi,b->hi,MPFR_RNDU);}static void subi(iv*z,const iv*a,const iv*b){mpfr_sub(z->lo,a->lo,b->hi,MPFR_RNDD);mpfr_sub(z->hi,a->hi,b->lo,MPFR_RNDU);}static void muli(iv*z,const iv*a,const iv*b){mpfr_t d[8];for(int i=0;i<8;i++)mi(d[i]);mpfr_srcptr av[2]={a->lo,a->hi},bv[2]={b->lo,b->hi};int n=0;for(int i=0;i<2;i++)for(int j=0;j<2;j++){mpfr_mul(d[n],av[i],bv[j],MPFR_RNDD);mpfr_mul(d[n+4],av[i],bv[j],MPFR_RNDU);n++;}int l=0,h=4;for(int i=1;i<4;i++){if(mpfr_cmp(d[i],d[l])<0)l=i;if(mpfr_cmp(d[i+4],d[h])>0)h=i+4;}mpfr_set(z->lo,d[l],MPFR_RNDD);mpfr_set(z->hi,d[h],MPFR_RNDU);for(int i=0;i<8;i++)mpfr_clear(d[i]);}static void divp(iv*z,const iv*a,const iv*b){mpfr_t l,h;mi(l);mi(h);mpfr_ui_div(l,1,b->hi,MPFR_RNDD);mpfr_ui_div(h,1,b->lo,MPFR_RNDU);iv inv;ii(&inv);mpfr_set(inv.lo,l,MPFR_RNDD);mpfr_set(inv.hi,h,MPFR_RNDU);muli(z,a,&inv);ic(&inv);mpfr_clear(l);mpfr_clear(h);}static void mului(iv*z,const iv*a,unsigned long n){mpfr_mul_ui(z->lo,a->lo,n,MPFR_RNDD);mpfr_mul_ui(z->hi,a->hi,n,MPFR_RNDU);}static void divui(iv*z,const iv*a,unsigned long n){mpfr_div_ui(z->lo,a->lo,n,MPFR_RNDD);mpfr_div_ui(z->hi,a->hi,n,MPFR_RNDU);}static void scale2i(iv*z,const iv*a,long e){mpfr_mul_2si(z->lo,a->lo,e,MPFR_RNDD);mpfr_mul_2si(z->hi,a->hi,e,MPFR_RNDU);}static void sqi(iv*z,const iv*a){
 mpfr_t l1,l2,h1,h2;mi(l1);mi(l2);mi(h1);mi(h2);
 mpfr_sqr(l1,a->lo,MPFR_RNDD);mpfr_sqr(l2,a->hi,MPFR_RNDD);
 mpfr_sqr(h1,a->lo,MPFR_RNDU);mpfr_sqr(h2,a->hi,MPFR_RNDU);
 if(mpfr_cmp_ui(a->lo,0)<=0&&mpfr_cmp_ui(a->hi,0)>=0)mpfr_set_ui(z->lo,0,MPFR_RNDD);
 else if(mpfr_cmp(l1,l2)<0)mpfr_set(z->lo,l1,MPFR_RNDD);else mpfr_set(z->lo,l2,MPFR_RNDD);
 if(mpfr_cmp(h1,h2)>0)mpfr_set(z->hi,h1,MPFR_RNDU);else mpfr_set(z->hi,h2,MPFR_RNDU);
 mpfr_clear(l1);mpfr_clear(l2);mpfr_clear(h1);mpfr_clear(h2);
}
static void sinlip(iv*z,const iv*a,ctx*c){midpoint_radius(c->t[0],c->t[1],a->lo,a->hi,c);mpfr_sin(c->t[2],c->t[0],MPFR_RNDD);mpfr_sin(c->t[3],c->t[0],MPFR_RNDU);mpfr_sub(z->lo,c->t[2],c->t[1],MPFR_RNDD);mpfr_add(z->hi,c->t[3],c->t[1],MPFR_RNDU);}static void coslip(iv*z,const iv*a,ctx*c){midpoint_radius(c->t[0],c->t[1],a->lo,a->hi,c);mpfr_cos(c->t[2],c->t[0],MPFR_RNDD);mpfr_cos(c->t[3],c->t[0],MPFR_RNDU);mpfr_sub(z->lo,c->t[2],c->t[1],MPFR_RNDD);mpfr_add(z->hi,c->t[3],c->t[1],MPFR_RNDU);} 

static void cubic(mpfr_t oc,mpfr_t orad,ball*s,size_t N,mpfr_srcptr step,mpfr_srcptr y,mpfr_srcptr yr,mpfr_srcptr d1,mpfr_srcptr d4,mpfr_srcptr tail,ctx*c){
 mpfr_div(c->t[0],y,step,MPFR_RNDN); long i=mpfr_get_si(c->t[0],MPFR_RNDD);mpfr_set_si(c->t[1],i,MPFR_RNDN);mpfr_sub(c->t[2],c->t[0],c->t[1],MPFR_RNDN); /* t */ mpfr_div(c->t[13],yr,step,MPFR_RNDU);mpfr_ui_sub(c->t[14],1,c->t[2],MPFR_RNDD);if(mpfr_cmp(c->t[2],c->t[13])<=0||mpfr_cmp(c->t[14],c->t[13])<=0){fprintf(stderr,"ambiguous interpolation cell\n");exit(4);}
 long ids[4]={(i-1+(long)N)%(long)N,(i+(long)N)%(long)N,(i+1)%(long)N,(i+2)%(long)N};
 /* L0=-t(t-1)(t-2)/6 */
 mpfr_sub_si(c->t[3],c->t[2],1,MPFR_RNDN);mpfr_sub_si(c->t[4],c->t[2],2,MPFR_RNDN);mpfr_mul(c->t[5],c->t[2],c->t[3],MPFR_RNDN);mpfr_mul(c->t[5],c->t[5],c->t[4],MPFR_RNDN);mpfr_div_si(c->t[5],c->t[5],-6,MPFR_RNDN);
 /* L1=(t+1)(t-1)(t-2)/2 */mpfr_add_ui(c->t[6],c->t[2],1,MPFR_RNDN);mpfr_mul(c->t[7],c->t[6],c->t[3],MPFR_RNDN);mpfr_mul(c->t[7],c->t[7],c->t[4],MPFR_RNDN);mpfr_div_ui(c->t[7],c->t[7],2,MPFR_RNDN);
 /* L2=-(t+1)t(t-2)/2 */mpfr_mul(c->t[8],c->t[6],c->t[2],MPFR_RNDN);mpfr_mul(c->t[8],c->t[8],c->t[4],MPFR_RNDN);mpfr_div_si(c->t[8],c->t[8],-2,MPFR_RNDN);
 /* L3=(t+1)t(t-1)/6 */mpfr_mul(c->t[9],c->t[6],c->t[2],MPFR_RNDN);mpfr_mul(c->t[9],c->t[9],c->t[3],MPFR_RNDN);mpfr_div_ui(c->t[9],c->t[9],6,MPFR_RNDN);
 mpfr_set_ui(oc,0,MPFR_RNDN);mpfr_set_ui(orad,0,MPFR_RNDU);int li[4]={5,7,8,9};for(int j=0;j<4;j++){mpfr_mul(c->t[10],c->t[li[j]],s[ids[j]].re,MPFR_RNDN);mpfr_add(oc,oc,c->t[10],MPFR_RNDN);mpfr_abs(c->t[11],c->t[li[j]],MPFR_RNDU);mpfr_mul(c->t[11],c->t[11],s[ids[j]].r,MPFR_RNDU);mpfr_add(orad,orad,c->t[11],MPFR_RNDU);} 
 mpfr_mul(c->t[12],step,step,MPFR_RNDU);mpfr_mul(c->t[12],c->t[12],c->t[12],MPFR_RNDU);mpfr_mul(c->t[12],c->t[12],d4,MPFR_RNDU);mpfr_mul_ui(c->t[12],c->t[12],3,MPFR_RNDU);mpfr_div_ui(c->t[12],c->t[12],128,MPFR_RNDU);mpfr_add(orad,orad,c->t[12],MPFR_RNDU);mpfr_mul(c->t[12],d1,yr,MPFR_RNDU);mpfr_add(orad,orad,c->t[12],MPFR_RNDU);mpfr_add(orad,orad,tail,MPFR_RNDU);mpfr_abs(c->t[12],oc,MPFR_RNDU);mpfr_add_ui(c->t[12],c->t[12],1,MPFR_RNDU);mpfr_mul(c->t[12],c->t[12],c->eps,MPFR_RNDU);mpfr_add(orad,orad,c->t[12],MPFR_RNDU);
}

int main(int argc,char**argv){int powN=16,K=4096,J0=64;if(argc>1)powN=atoi(argv[1]);if(argc>2)K=atoi(argv[2]);size_t N=(size_t)1<<powN;if(K>=(int)N/2)return 2;ctx c;ctx_init(&c);ball*a=malloc(N*sizeof(ball));for(size_t i=0;i<N;i++)ball_init(&a[i]);
 iv pi,S,hv,tmp,two,gam[5],rn[5];ii(&pi);mpfr_const_pi(pi.lo,MPFR_RNDD);mpfr_const_pi(pi.hi,MPFR_RNDU);ii(&S);setu(&S,1);ii(&hv);mpfr_set_ui(c.t[0],4,MPFR_RNDN);mpfr_log(hv.lo,c.t[0],MPFR_RNDD);mpfr_log(hv.hi,c.t[0],MPFR_RNDU);ii(&tmp);ii(&two);setu(&two,2);const char*zs[5]={"14.13472514173469379045725198356247","21.02203963877155499262847959389690","25.01085758014568876321379099256282","30.42487612585951321031189753058409","32.93506158773918969066236896407490"};for(int j=0;j<5;j++){ii(&gam[j]);sets(&gam[j],zs[j]);ii(&rn[j]);mului(&tmp,&pi,2);divp(&rn[j],&tmp,&gam[j]);addi(&S,&S,&rn[j]);}
 mpfr_t step,d1,d4,tail0,Sc,Sr,hc,hr;mi(step);mpfr_set_ui(step,8,MPFR_RNDN);mpfr_mul_2si(step,step,-powN,MPFR_RNDN);mi(d1);mi(d4);mpfr_set_ui(d1,0,MPFR_RNDU);mpfr_set_ui(d4,0,MPFR_RNDU);mi(tail0);mpfr_set_str(tail0,"1.4e-29",10,MPFR_RNDU);mi(Sc);mi(Sr);mi(hc);mi(hr);midpoint_radius(Sc,Sr,S.lo,S.hi,&c);midpoint_radius(hc,hr,hv.lo,hv.hi,&c);
 for(int k=0;k<=K;k++){iv prod,omega,arg,sn,sq,amp,phase,cs,ss,re,im,delta,tf,one;ii(&prod);setu(&prod,1);ii(&omega);mului(&omega,&pi,(unsigned long)k);divui(&omega,&omega,4);ii(&arg);ii(&sn);ii(&sq);ii(&amp);ii(&phase);ii(&cs);ii(&ss);ii(&re);ii(&im);ii(&delta);ii(&tf);ii(&one);setu(&one,1);if(k){for(int j=0;j<5;j++){muli(&arg,&omega,&rn[j]);divui(&arg,&arg,2);sinlip(&sn,&arg,&c);divp(&sn,&sn,&arg);sqi(&sq,&sn);muli(&prod,&prod,&sq);}for(int j=1;j<=J0;j++){scale2i(&arg,&omega,-(j+1));sinlip(&sn,&arg,&c);divp(&sn,&sn,&arg);sqi(&sq,&sn);muli(&prod,&prod,&sq);}sqi(&delta,&omega);scale2i(&delta,&delta,-2*J0);divui(&delta,&delta,36);subi(&tf,&one,&delta);if(mpfr_cmp_ui(tf.lo,0)<0)mpfr_set_ui(tf.lo,0,MPFR_RNDD);mpfr_set_ui(tf.hi,1,MPFR_RNDU);muli(&prod,&prod,&tf);}divui(&amp,&prod,8);/* form -omega*S without in-place endpoint aliasing */muli(&phase,&omega,&S);mpfr_neg(c.t[0],phase.hi,MPFR_RNDD);mpfr_neg(c.t[1],phase.lo,MPFR_RNDU);mpfr_set(phase.lo,c.t[0],MPFR_RNDD);mpfr_set(phase.hi,c.t[1],MPFR_RNDU);coslip(&cs,&phase,&c);sinlip(&ss,&phase,&c);muli(&re,&amp,&cs);muli(&im,&amp,&ss);ball_from_rect(&a[k],re.lo,re.hi,im.lo,im.hi,&c);ball_scale2(&a[k],powN);if(k){ball_copy(&a[N-k],&a[k]);mpfr_neg(a[N-k].im,a[N-k].im,MPFR_RNDN);}mpfr_abs(c.t[0],amp.hi,MPFR_RNDU);mpfr_abs(c.t[1],omega.hi,MPFR_RNDU);mpfr_mul(c.t[2],c.t[0],c.t[1],MPFR_RNDU);if(k)mpfr_mul_ui(c.t[2],c.t[2],2,MPFR_RNDU);mpfr_add(d1,d1,c.t[2],MPFR_RNDU);mpfr_mul(c.t[2],c.t[2],c.t[1],MPFR_RNDU);mpfr_mul(c.t[2],c.t[2],c.t[1],MPFR_RNDU);mpfr_mul(c.t[2],c.t[2],c.t[1],MPFR_RNDU);mpfr_add(d4,d4,c.t[2],MPFR_RNDU);
 iv*all[]={&prod,&omega,&arg,&sn,&sq,&amp,&phase,&cs,&ss,&re,&im,&delta,&tf,&one};for(size_t z=0;z<sizeof(all)/sizeof(all[0]);z++)ic(all[z]);}
 mpfr_set_str(c.t[0],"1.5e-15",10,MPFR_RNDU);mpfr_add(d4,d4,c.t[0],MPFR_RNDU);
 ball*wlen=malloc(powN*sizeof(ball));for(int s=0;s<powN;s++)ball_init(&wlen[s]);size_t len=2;for(int s=0;s<powN;s++,len<<=1){mpfr_mul_ui(c.t[0],pi.lo,2,MPFR_RNDD);mpfr_div_ui(c.t[0],c.t[0],len,MPFR_RNDD);mpfr_cos(wlen[s].re,c.t[0],MPFR_RNDN);mpfr_sin(wlen[s].im,c.t[0],MPFR_RNDN);mpfr_set(wlen[s].r,c.eps,MPFR_RNDU);}fft(a,N,1,wlen,&c);
 int limit=1500000;uint8_t*is=sieve(limit);size_t cap=150000,ne=0;event*ev=malloc(cap*sizeof(event));for(int p=2;p<=limit;p++)if(is[p]){mpfr_t lplo,lphi,lpc,lpr;mi(lplo);mi(lphi);mi(lpc);mi(lpr);mpfr_set_ui(c.t[0],p,MPFR_RNDN);mpfr_log(lplo,c.t[0],MPFR_RNDD);mpfr_log(lphi,c.t[0],MPFR_RNDU);midpoint_radius(lpc,lpr,lplo,lphi,&c);long long v=p;while(v<=limit){if(ne==cap){cap*=2;ev=realloc(ev,cap*sizeof(event));}event_init(&ev[ne]);ev[ne].n=(int)v;ev[ne].p=p;mpfr_t llo,lhi,slo,shi,wlo,whi;mi(llo);mi(lhi);mi(slo);mi(shi);mi(wlo);mi(whi);mpfr_set_ui(c.t[0],(unsigned long)v,MPFR_RNDN);mpfr_log(llo,c.t[0],MPFR_RNDD);mpfr_log(lhi,c.t[0],MPFR_RNDU);mpfr_sqrt(slo,c.t[0],MPFR_RNDD);mpfr_sqrt(shi,c.t[0],MPFR_RNDU);mpfr_div(wlo,lplo,shi,MPFR_RNDD);mpfr_div(whi,lphi,slo,MPFR_RNDU);midpoint_radius(ev[ne].lc,ev[ne].lr,llo,lhi,&c);midpoint_radius(ev[ne].wc,ev[ne].wr,wlo,whi,&c);mpfr_clear(llo);mpfr_clear(lhi);mpfr_clear(slo);mpfr_clear(shi);mpfr_clear(wlo);mpfr_clear(whi);ne++;if(v>limit/p)break;v*=p;}mpfr_clear(lplo);mpfr_clear(lphi);mpfr_clear(lpc);mpfr_clear(lpr);}qsort(ev,ne,sizeof(event),cmp_event);
 mpfr_t x,sum,srad,yc,yr,y1,y1r,y2,y2r,fc,fr,gc,gr,tc,tr,maxsup,maxr,fmax;mi(x);mpfr_set_ui(x,8578244975439ULL,MPFR_RNDN);mpfr_div_2si(x,x,39,MPFR_RNDN);mi(sum);mi(srad);mpfr_set_ui(sum,0,MPFR_RNDN);mpfr_set_ui(srad,0,MPFR_RNDU);mi(yc);mi(yr);mi(y1);mi(y1r);mi(y2);mi(y2r);mi(fc);mi(fr);mi(gc);mi(gr);mi(tc);mi(tr);mi(maxsup);mi(maxr);mi(fmax);mpfr_mul_ui(fmax,Sc,2,MPFR_RNDU);mpfr_mul_ui(c.t[3],Sr,2,MPFR_RNDU);mpfr_add(fmax,fmax,c.t[3],MPFR_RNDU);mpfr_mul_ui(maxsup,Sc,2,MPFR_RNDU);mpfr_add_ui(maxsup,maxsup,2,MPFR_RNDU);mpfr_add(maxsup,maxsup,hc,MPFR_RNDU);mpfr_mul_ui(maxr,Sr,2,MPFR_RNDU);mpfr_add(maxr,maxr,hr,MPFR_RNDU);size_t cnt=0;
 for(size_t e=0;e<ne;e++){mpfr_sub(yc,x,ev[e].lc,MPFR_RNDN);mpfr_set(yr,ev[e].lr,MPFR_RNDU);mpfr_add(c.t[0],yc,yr,MPFR_RNDU);if(mpfr_cmp_ui(c.t[0],2)<0)continue;mpfr_sub(c.t[0],yc,yr,MPFR_RNDD);mpfr_add(c.t[1],maxsup,maxr,MPFR_RNDU);if(mpfr_cmp(c.t[0],c.t[1])>0)continue;mpfr_set_ui(gc,0,MPFR_RNDN);mpfr_set_ui(gr,0,MPFR_RNDU);mpfr_sub_ui(y1,yc,2,MPFR_RNDN);mpfr_set(y1r,yr,MPFR_RNDU);mpfr_add(c.t[0],y1,y1r,MPFR_RNDU);mpfr_sub(c.t[1],y1,y1r,MPFR_RNDD);if(mpfr_cmp_ui(c.t[0],0)<0||mpfr_cmp(c.t[1],fmax)>0){if(!(mpfr_cmp_ui(c.t[0],0)<0&&mpfr_cmp_ui(c.t[1],0)<0)&&!(mpfr_cmp(c.t[0],fmax)>0&&mpfr_cmp(c.t[1],fmax)>0)){fprintf(stderr,"ambiguous first-window support boundary\n");exit(5);}}else{cubic(fc,fr,a,N,step,y1,y1r,d1,d4,tail0,&c);mpfr_add(gc,gc,fc,MPFR_RNDN);mpfr_add(gr,gr,fr,MPFR_RNDU);}mpfr_sub(y2,yc,hc,MPFR_RNDN);mpfr_sub_ui(y2,y2,2,MPFR_RNDN);mpfr_add(y2r,yr,hr,MPFR_RNDU);mpfr_add(c.t[0],y2,y2r,MPFR_RNDU);mpfr_sub(c.t[1],y2,y2r,MPFR_RNDD);if(mpfr_cmp_ui(c.t[0],0)<0||mpfr_cmp(c.t[1],fmax)>0){if(!(mpfr_cmp_ui(c.t[0],0)<0&&mpfr_cmp_ui(c.t[1],0)<0)&&!(mpfr_cmp(c.t[0],fmax)>0&&mpfr_cmp(c.t[1],fmax)>0)){fprintf(stderr,"ambiguous shifted-window support boundary\n");exit(6);}}else{cubic(fc,fr,a,N,step,y2,y2r,d1,d4,tail0,&c);mpfr_mul_ui(fc,fc,2,MPFR_RNDN);mpfr_sub(gc,gc,fc,MPFR_RNDN);mpfr_mul_ui(fr,fr,2,MPFR_RNDU);mpfr_add(gr,gr,fr,MPFR_RNDU);}mpfr_abs(c.t[4],gc,MPFR_RNDU);mpfr_add_ui(c.t[4],c.t[4],1,MPFR_RNDU);mpfr_mul(c.t[4],c.t[4],c.eps,MPFR_RNDU);mpfr_add(gr,gr,c.t[4],MPFR_RNDU);mpfr_mul(tc,ev[e].wc,gc,MPFR_RNDN);mpfr_abs(c.t[0],ev[e].wc,MPFR_RNDU);mpfr_mul(tr,c.t[0],gr,MPFR_RNDU);mpfr_abs(c.t[0],gc,MPFR_RNDU);mpfr_mul(c.t[0],c.t[0],ev[e].wr,MPFR_RNDU);mpfr_add(tr,tr,c.t[0],MPFR_RNDU);mpfr_mul(c.t[0],ev[e].wr,gr,MPFR_RNDU);mpfr_add(tr,tr,c.t[0],MPFR_RNDU);mpfr_abs(c.t[0],tc,MPFR_RNDU);mpfr_add_ui(c.t[0],c.t[0],1,MPFR_RNDU);mpfr_mul(c.t[0],c.t[0],c.eps,MPFR_RNDU);mpfr_add(tr,tr,c.t[0],MPFR_RNDU);mpfr_add(sum,sum,tc,MPFR_RNDN);mpfr_add(srad,srad,tr,MPFR_RNDU);mpfr_abs(c.t[0],sum,MPFR_RNDU);mpfr_add_ui(c.t[0],c.t[0],1,MPFR_RNDU);mpfr_mul(c.t[0],c.t[0],c.eps,MPFR_RNDU);mpfr_add(srad,srad,c.t[0],MPFR_RNDU);cnt++;}
 printf("pow=%d K=%d terms=%zu\n",powN,K,cnt);printv("prime_center",sum);printv("prime_radius",srad);mpfr_sub(c.t[0],sum,srad,MPFR_RNDD);mpfr_add(c.t[1],sum,srad,MPFR_RNDU);printv("prime_lower",c.t[0]);printv("prime_upper",c.t[1]);
 return 0;
}
