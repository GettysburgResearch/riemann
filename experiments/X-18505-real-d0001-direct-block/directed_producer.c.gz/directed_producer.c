#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <gmp.h>

/* Minimal MPFR declarations: the runtime library is available but headers are not. */
typedef long mpfr_prec_t;
typedef long mpfr_exp_t;
typedef int mpfr_sign_t;
typedef unsigned long mp_limb_t;
typedef struct { mpfr_prec_t _mpfr_prec; mpfr_sign_t _mpfr_sign; mpfr_exp_t _mpfr_exp; mp_limb_t *_mpfr_d; } __mpfr_struct;
typedef __mpfr_struct mpfr_t[1];
typedef __mpfr_struct *mpfr_ptr;
typedef const __mpfr_struct *mpfr_srcptr;
typedef enum {MPFR_RNDN=0, MPFR_RNDZ=1, MPFR_RNDU=2, MPFR_RNDD=3, MPFR_RNDA=4} mpfr_rnd_t;
extern void mpfr_init2(mpfr_ptr, mpfr_prec_t);
extern void mpfr_clear(mpfr_ptr);
extern int mpfr_set(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_set_ui(mpfr_ptr, unsigned long, mpfr_rnd_t);
extern int mpfr_set_si(mpfr_ptr, long, mpfr_rnd_t);
extern int mpfr_set_z(mpfr_ptr, mpz_srcptr, mpfr_rnd_t);
extern int mpfr_set_str(mpfr_ptr, const char*, int, mpfr_rnd_t);
extern int mpfr_add(mpfr_ptr, mpfr_srcptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_sub(mpfr_ptr, mpfr_srcptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_mul(mpfr_ptr, mpfr_srcptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_div(mpfr_ptr, mpfr_srcptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_mul_si(mpfr_ptr, mpfr_srcptr, long, mpfr_rnd_t);
extern int mpfr_div_si(mpfr_ptr, mpfr_srcptr, long, mpfr_rnd_t);
extern int mpfr_ui_div(mpfr_ptr, unsigned long, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_neg(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_abs(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_sqrt(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_log(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_exp(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_sin(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_cos(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_sinh(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_atan(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
extern int mpfr_const_pi(mpfr_ptr, mpfr_rnd_t);
extern int mpfr_const_euler(mpfr_ptr, mpfr_rnd_t);
extern int mpfr_cmp(mpfr_srcptr, mpfr_srcptr);
extern int mpfr_sgn(mpfr_srcptr);
extern mpfr_exp_t mpfr_get_z_2exp(mpz_ptr, mpfr_srcptr);
extern int mpfr_printf(const char*, ...);

#ifndef PREC
#define PREC 256
#endif
#define PSI_N 300000

typedef struct { mpfr_t lo, hi; } iv;
typedef struct { iv re, im; } civ;

static void die(const char *msg){ fprintf(stderr,"ERROR: %s\n",msg); exit(2); }
static void iv_init(iv *x){ mpfr_init2(x->lo,PREC); mpfr_init2(x->hi,PREC); }
static void iv_clear(iv *x){ mpfr_clear(x->lo); mpfr_clear(x->hi); }
static void civ_init(civ *z){ iv_init(&z->re); iv_init(&z->im); }
static void civ_clear(civ *z){ iv_clear(&z->re); iv_clear(&z->im); }
static void iv_set(iv *z,const iv *a){ mpfr_set(z->lo,a->lo,MPFR_RNDD); mpfr_set(z->hi,a->hi,MPFR_RNDU); }
static void iv_set_ui(iv *z,unsigned long a){ mpfr_set_ui(z->lo,a,MPFR_RNDD); mpfr_set_ui(z->hi,a,MPFR_RNDU); }
static void iv_set_si(iv *z,long a){ mpfr_set_si(z->lo,a,MPFR_RNDD); mpfr_set_si(z->hi,a,MPFR_RNDU); }
static void iv_set_str(iv *z,const char *s){ if(mpfr_set_str(z->lo,s,10,MPFR_RNDD)||mpfr_set_str(z->hi,s,10,MPFR_RNDU)) die("bad decimal integer"); }
static void iv_set_frac(iv *z,long n,long d){ iv a,b;iv_init(&a);iv_init(&b);iv_set_si(&a,n);iv_set_si(&b,d); /* forward decl */
    mpfr_div(z->lo,a.lo,b.hi,MPFR_RNDD); mpfr_div(z->hi,a.hi,b.lo,MPFR_RNDU);iv_clear(&a);iv_clear(&b); }
static void iv_const_pi(iv *z){mpfr_const_pi(z->lo,MPFR_RNDD);mpfr_const_pi(z->hi,MPFR_RNDU);}
static void iv_const_euler(iv *z){mpfr_const_euler(z->lo,MPFR_RNDD);mpfr_const_euler(z->hi,MPFR_RNDU);}
static void iv_add(iv *z,const iv *a,const iv *b){mpfr_add(z->lo,a->lo,b->lo,MPFR_RNDD);mpfr_add(z->hi,a->hi,b->hi,MPFR_RNDU);}
static void iv_sub(iv *z,const iv *a,const iv *b){mpfr_t l,u;mpfr_init2(l,PREC);mpfr_init2(u,PREC);mpfr_sub(l,a->lo,b->hi,MPFR_RNDD);mpfr_sub(u,a->hi,b->lo,MPFR_RNDU);mpfr_set(z->lo,l,MPFR_RNDD);mpfr_set(z->hi,u,MPFR_RNDU);mpfr_clear(l);mpfr_clear(u);}
static void iv_neg(iv *z,const iv *a){mpfr_t l,u;mpfr_init2(l,PREC);mpfr_init2(u,PREC);mpfr_neg(l,a->hi,MPFR_RNDD);mpfr_neg(u,a->lo,MPFR_RNDU);mpfr_set(z->lo,l,MPFR_RNDD);mpfr_set(z->hi,u,MPFR_RNDU);mpfr_clear(l);mpfr_clear(u);}
static void iv_mul(iv *z,const iv *a,const iv *b){
    mpfr_t d[4],u[4]; for(int i=0;i<4;i++){mpfr_init2(d[i],PREC);mpfr_init2(u[i],PREC);} 
    mpfr_mul(d[0],a->lo,b->lo,MPFR_RNDD); mpfr_mul(u[0],a->lo,b->lo,MPFR_RNDU);
    mpfr_mul(d[1],a->lo,b->hi,MPFR_RNDD); mpfr_mul(u[1],a->lo,b->hi,MPFR_RNDU);
    mpfr_mul(d[2],a->hi,b->lo,MPFR_RNDD); mpfr_mul(u[2],a->hi,b->lo,MPFR_RNDU);
    mpfr_mul(d[3],a->hi,b->hi,MPFR_RNDD); mpfr_mul(u[3],a->hi,b->hi,MPFR_RNDU);
    mpfr_set(z->lo,d[0],MPFR_RNDD); mpfr_set(z->hi,u[0],MPFR_RNDU);
    for(int i=1;i<4;i++){ if(mpfr_cmp(d[i],z->lo)<0) mpfr_set(z->lo,d[i],MPFR_RNDD); if(mpfr_cmp(u[i],z->hi)>0) mpfr_set(z->hi,u[i],MPFR_RNDU); }
    for(int i=0;i<4;i++){mpfr_clear(d[i]);mpfr_clear(u[i]);}
}

static void iv_square(iv *z,const iv *a){
    mpfr_t l,u,t1,t2;mpfr_init2(l,PREC);mpfr_init2(u,PREC);mpfr_init2(t1,PREC);mpfr_init2(t2,PREC);
    if(mpfr_sgn(a->lo)>=0){mpfr_mul(l,a->lo,a->lo,MPFR_RNDD);mpfr_mul(u,a->hi,a->hi,MPFR_RNDU);}
    else if(mpfr_sgn(a->hi)<=0){mpfr_mul(l,a->hi,a->hi,MPFR_RNDD);mpfr_mul(u,a->lo,a->lo,MPFR_RNDU);}
    else{mpfr_set_ui(l,0,MPFR_RNDD);mpfr_mul(t1,a->lo,a->lo,MPFR_RNDU);mpfr_mul(t2,a->hi,a->hi,MPFR_RNDU);if(mpfr_cmp(t1,t2)>=0)mpfr_set(u,t1,MPFR_RNDU);else mpfr_set(u,t2,MPFR_RNDU);}
    mpfr_set(z->lo,l,MPFR_RNDD);mpfr_set(z->hi,u,MPFR_RNDU);mpfr_clear(l);mpfr_clear(u);mpfr_clear(t1);mpfr_clear(t2);
}
static void iv_recip(iv *z,const iv *a){
    if(mpfr_sgn(a->lo)<=0 && mpfr_sgn(a->hi)>=0) die("division interval contains zero");
    mpfr_t one;mpfr_init2(one,PREC);mpfr_set_ui(one,1,MPFR_RNDN);
    if(mpfr_sgn(a->lo)>0){ mpfr_div(z->lo,one,a->hi,MPFR_RNDD);mpfr_div(z->hi,one,a->lo,MPFR_RNDU); }
    else { mpfr_div(z->lo,one,a->hi,MPFR_RNDD);mpfr_div(z->hi,one,a->lo,MPFR_RNDU); }
    mpfr_clear(one);
}
static void iv_div(iv *z,const iv *a,const iv *b){iv r;iv_init(&r);iv_recip(&r,b);iv_mul(z,a,&r);iv_clear(&r);}
static void iv_scale_si(iv *z,const iv *a,long n){mpfr_t l,u;mpfr_init2(l,PREC);mpfr_init2(u,PREC);if(n>=0){mpfr_mul_si(l,a->lo,n,MPFR_RNDD);mpfr_mul_si(u,a->hi,n,MPFR_RNDU);}else{mpfr_mul_si(l,a->hi,n,MPFR_RNDD);mpfr_mul_si(u,a->lo,n,MPFR_RNDU);}mpfr_set(z->lo,l,MPFR_RNDD);mpfr_set(z->hi,u,MPFR_RNDU);mpfr_clear(l);mpfr_clear(u);}
static void iv_sqrt(iv *z,const iv *a){if(mpfr_sgn(a->lo)<0)die("sqrt negative");mpfr_sqrt(z->lo,a->lo,MPFR_RNDD);mpfr_sqrt(z->hi,a->hi,MPFR_RNDU);}
static void iv_log(iv *z,const iv *a){if(mpfr_sgn(a->lo)<=0)die("log nonpositive");mpfr_log(z->lo,a->lo,MPFR_RNDD);mpfr_log(z->hi,a->hi,MPFR_RNDU);}
static void iv_exp(iv *z,const iv *a){mpfr_exp(z->lo,a->lo,MPFR_RNDD);mpfr_exp(z->hi,a->hi,MPFR_RNDU);}
static void iv_sinh(iv *z,const iv *a){mpfr_sinh(z->lo,a->lo,MPFR_RNDD);mpfr_sinh(z->hi,a->hi,MPFR_RNDU);}
static void iv_atan(iv *z,const iv *a){mpfr_atan(z->lo,a->lo,MPFR_RNDD);mpfr_atan(z->hi,a->hi,MPFR_RNDU);}
static void iv_mid_rad(mpfr_ptr mid,mpfr_ptr rad,const iv *a){
    mpfr_t t1,t2;mpfr_init2(t1,PREC);mpfr_init2(t2,PREC);
    mpfr_add(mid,a->lo,a->hi,MPFR_RNDN);mpfr_div_si(mid,mid,2,MPFR_RNDN);
    mpfr_sub(t1,mid,a->lo,MPFR_RNDU);mpfr_abs(t1,t1,MPFR_RNDU);
    mpfr_sub(t2,a->hi,mid,MPFR_RNDU);mpfr_abs(t2,t2,MPFR_RNDU);
    if(mpfr_cmp(t1,t2)>=0)mpfr_set(rad,t1,MPFR_RNDU);else mpfr_set(rad,t2,MPFR_RNDU);
    mpfr_clear(t1);mpfr_clear(t2);
}
static void iv_sin(iv *z,const iv *a){mpfr_t m,r,l,u;mpfr_init2(m,PREC);mpfr_init2(r,PREC);mpfr_init2(l,PREC);mpfr_init2(u,PREC);iv_mid_rad(m,r,a);mpfr_sin(l,m,MPFR_RNDD);mpfr_sin(u,m,MPFR_RNDU);mpfr_sub(z->lo,l,r,MPFR_RNDD);mpfr_add(z->hi,u,r,MPFR_RNDU);mpfr_clear(m);mpfr_clear(r);mpfr_clear(l);mpfr_clear(u);}
static void iv_cos(iv *z,const iv *a){mpfr_t m,r,l,u;mpfr_init2(m,PREC);mpfr_init2(r,PREC);mpfr_init2(l,PREC);mpfr_init2(u,PREC);iv_mid_rad(m,r,a);mpfr_cos(l,m,MPFR_RNDD);mpfr_cos(u,m,MPFR_RNDU);mpfr_sub(z->lo,l,r,MPFR_RNDD);mpfr_add(z->hi,u,r,MPFR_RNDU);mpfr_clear(m);mpfr_clear(r);mpfr_clear(l);mpfr_clear(u);}
static void iv_abs_upper(mpfr_ptr u,const iv *a){mpfr_t x,y;mpfr_init2(x,PREC);mpfr_init2(y,PREC);mpfr_abs(x,a->lo,MPFR_RNDU);mpfr_abs(y,a->hi,MPFR_RNDU);if(mpfr_cmp(x,y)>=0)mpfr_set(u,x,MPFR_RNDU);else mpfr_set(u,y,MPFR_RNDU);mpfr_clear(x);mpfr_clear(y);}
static void iv_add_symmetric_error(iv *z,const mpfr_srcptr e){mpfr_sub(z->lo,z->lo,e,MPFR_RNDD);mpfr_add(z->hi,z->hi,e,MPFR_RNDU);}
static int iv_lower_positive(const iv *x){return mpfr_sgn(x->lo)>0;}

static void civ_set(civ *z,const civ *a){iv_set(&z->re,&a->re);iv_set(&z->im,&a->im);}
static void civ_add(civ *z,const civ *a,const civ *b){iv_add(&z->re,&a->re,&b->re);iv_add(&z->im,&a->im,&b->im);}
static void civ_sub(civ *z,const civ *a,const civ *b){iv_sub(&z->re,&a->re,&b->re);iv_sub(&z->im,&a->im,&b->im);}
static void civ_mul(civ *z,const civ *a,const civ *b){iv ac,bd,ad,bc;iv_init(&ac);iv_init(&bd);iv_init(&ad);iv_init(&bc);iv_mul(&ac,&a->re,&b->re);iv_mul(&bd,&a->im,&b->im);iv_mul(&ad,&a->re,&b->im);iv_mul(&bc,&a->im,&b->re);iv_sub(&z->re,&ac,&bd);iv_add(&z->im,&ad,&bc);iv_clear(&ac);iv_clear(&bd);iv_clear(&ad);iv_clear(&bc);}
static void civ_recip(civ *z,const civ *a){iv x2,y2,d,nim;iv_init(&x2);iv_init(&y2);iv_init(&d);iv_init(&nim);iv_mul(&x2,&a->re,&a->re);iv_mul(&y2,&a->im,&a->im);iv_add(&d,&x2,&y2);iv_div(&z->re,&a->re,&d);iv_neg(&nim,&a->im);iv_div(&z->im,&nim,&d);iv_clear(&x2);iv_clear(&y2);iv_clear(&d);iv_clear(&nim);}
static void civ_add_symmetric_error(civ *z,const mpfr_srcptr e){iv_add_symmetric_error(&z->re,e);iv_add_symmetric_error(&z->im,e);}

static void print_endpoint(mpfr_srcptr x){if(mpfr_sgn(x)==0){printf("{\"mantissa\":\"0\",\"exponent\":0}");return;}mpz_t m;mpz_init(m);mpfr_exp_t e=mpfr_get_z_2exp(m,x);char *s=mpz_get_str(NULL,10,m);printf("{\"mantissa\":\"%s\",\"exponent\":%ld}",s,(long)e);free(s);mpz_clear(m);}
static void print_iv(const iv *x){printf("{\"lower\":");print_endpoint(x->lo);printf(",\"upper\":");print_endpoint(x->hi);printf("}");}

static void digamma_and_trigamma(civ *psi,civ *psi1,const iv *zr,const iv *zi){
    iv euler;iv_init(&euler);iv_const_euler(&euler);iv_neg(&psi->re,&euler);iv_set_si(&psi->im,0);iv_set_si(&psi1->re,0);iv_set_si(&psi1->im,0);
    civ z, kz, inv, inv2, term; civ_init(&z);civ_init(&kz);civ_init(&inv);civ_init(&inv2);civ_init(&term);iv_set(&z.re,zr);iv_set(&z.im,zi);
    iv one_over;iv_init(&one_over);
    for(long k=0;k<PSI_N;k++){
        iv_set_si(&kz.re,k);iv_add(&kz.re,&kz.re,zr);iv_set(&kz.im,zi);
        civ_recip(&inv,&kz);
        iv den;iv_init(&den);iv_set_si(&den,k+1);iv_set_si(&one_over,1);iv_div(&one_over,&one_over,&den);
        iv_sub(&term.re,&one_over,&inv.re);iv_neg(&term.im,&inv.im);civ_add(psi,psi,&term);
        civ_mul(&inv2,&inv,&inv);civ_add(psi1,psi1,&inv2);
        iv_clear(&den);
    }
    /* rigorous absolute tails */
    mpfr_t ab, tr, ti, q, npa;mpfr_init2(ab,PREC);mpfr_init2(tr,PREC);mpfr_init2(ti,PREC);mpfr_init2(q,PREC);mpfr_init2(npa,PREC);
    iv zm1r;iv_init(&zm1r);iv one;iv_init(&one);iv_set_si(&one,1);iv_sub(&zm1r,zr,&one);
    mpfr_t ar,ai;mpfr_init2(ar,PREC);mpfr_init2(ai,PREC);iv_abs_upper(ar,&zm1r);iv_abs_upper(ai,zi);mpfr_mul(ar,ar,ar,MPFR_RNDU);mpfr_mul(ai,ai,ai,MPFR_RNDU);mpfr_add(ab,ar,ai,MPFR_RNDU);mpfr_sqrt(ab,ab,MPFR_RNDU);
    mpfr_set_ui(npa,PSI_N,MPFR_RNDU);mpfr_add(npa,npa,zr->hi,MPFR_RNDU);
    mpfr_ui_div(q,1,npa,MPFR_RNDU);mpfr_mul(tr,q,q,MPFR_RNDU);mpfr_add(tr,tr,q,MPFR_RNDU); /* 1/x+1/x^2 */
    mpfr_mul(ti,ab,tr,MPFR_RNDU);
    civ_add_symmetric_error(psi,ti);civ_add_symmetric_error(psi1,tr);
    mpfr_clear(ab);mpfr_clear(tr);mpfr_clear(ti);mpfr_clear(q);mpfr_clear(npa);mpfr_clear(ar);mpfr_clear(ai);iv_clear(&zm1r);iv_clear(&one);
    iv_clear(&one_over);civ_clear(&z);civ_clear(&kz);civ_clear(&inv);civ_clear(&inv2);civ_clear(&term);iv_clear(&euler);
}

static void geometric_sums(int n,const iv *L,iv *gs,iv *gcc,iv *gx1,iv *gx2){
    iv_set_si(gs,0);iv_set_si(gcc,0);iv_set_si(gx1,0);iv_set_si(gx2,0);
    iv pi,w,w2,ratio,omr;iv_init(&pi);iv_init(&w);iv_init(&w2);iv_init(&ratio);iv_init(&omr);iv_const_pi(&pi);iv_scale_si(&w,&pi,2*n);iv_div(&w,&w,L);iv_mul(&w2,&w,&w);
    iv t;iv_init(&t);iv_scale_si(&t,L,-2);iv_exp(&ratio,&t);iv one;iv_init(&one);iv_set_si(&one,1);iv_sub(&omr,&one,&ratio);
    mpfr_t target;mpfr_init2(target,PREC);mpfr_set_ui(target,1,MPFR_RNDN);for(int i=0;i<180;i++)mpfr_div_si(target,target,2,MPFR_RNDU);
    for(long k=0;k<100000;k++){
        iv ck,neg,ek,ck2,den,a,b,num;iv_init(&ck);iv_init(&neg);iv_init(&ek);iv_init(&ck2);iv_init(&den);iv_init(&a);iv_init(&b);iv_init(&num);
        iv_set_si(&ck,2*k);iv half;iv_init(&half);iv_set_frac(&half,1,2);iv_add(&ck,&ck,&half);
        iv_mul(&neg,&ck,L);iv_neg(&neg,&neg);iv_exp(&ek,&neg);iv_mul(&ck2,&ck,&ck);iv_add(&den,&ck2,&w2);
        iv_div(&a,&ek,&den);iv_add(gs,gs,&a);
        if(n){iv_mul(&num,&ek,&w2);iv_mul(&b,&ck,&den);iv_div(&a,&num,&b);iv_add(gcc,gcc,&a);}
        iv_mul(&num,&ek,&ck);iv_div(&a,&num,&den);iv_add(gx1,gx1,&a);
        iv_sub(&num,&ck2,&w2);iv_mul(&num,&num,&ek);iv_mul(&b,&den,&den);iv_div(&a,&num,&b);iv_add(gx2,gx2,&a);
        /* tail check at cnext */
        iv cnext,en,env,bsq,blin;iv_init(&cnext);iv_init(&en);iv_init(&env);iv_init(&bsq);iv_init(&blin);iv_set_si(&cnext,2*k+2);iv_add(&cnext,&cnext,&half);iv_mul(&en,&cnext,L);iv_neg(&en,&en);iv_exp(&en,&en);iv_div(&env,&en,&omr);iv_mul(&bsq,&cnext,&cnext);iv_div(&bsq,&env,&bsq);iv_div(&blin,&env,&cnext);
        mpfr_t ub;mpfr_init2(ub,PREC);iv_abs_upper(ub,n?&blin:&blin);
        int stop=mpfr_cmp(ub,target)<0;
        if(stop){iv_add_symmetric_error(gs,bsq.hi);if(n)iv_add_symmetric_error(gcc,blin.hi);iv_add_symmetric_error(gx1,blin.hi);iv_add_symmetric_error(gx2,bsq.hi);mpfr_clear(ub);iv_clear(&cnext);iv_clear(&en);iv_clear(&env);iv_clear(&bsq);iv_clear(&blin);iv_clear(&half);iv_clear(&ck);iv_clear(&neg);iv_clear(&ek);iv_clear(&ck2);iv_clear(&den);iv_clear(&a);iv_clear(&b);iv_clear(&num);break;}
        mpfr_clear(ub);iv_clear(&cnext);iv_clear(&en);iv_clear(&env);iv_clear(&bsq);iv_clear(&blin);iv_clear(&half);iv_clear(&ck);iv_clear(&neg);iv_clear(&ek);iv_clear(&ck2);iv_clear(&den);iv_clear(&a);iv_clear(&b);iv_clear(&num);
        if(k==99999)die("geometric tail loop failed");
    }
    mpfr_clear(target);iv_clear(&pi);iv_clear(&w);iv_clear(&w2);iv_clear(&ratio);iv_clear(&omr);iv_clear(&t);iv_clear(&one);
}

static void mat_quad(iv *out,iv M[2][2],const iv v[2],const iv w[2]){iv_set_si(out,0);for(int i=0;i<2;i++)for(int j=0;j<2;j++){iv a,b;iv_init(&a);iv_init(&b);iv_mul(&a,&v[i],&M[i][j]);iv_mul(&b,&a,&w[j]);iv_add(out,out,&b);iv_clear(&a);iv_clear(&b);}}

int main(void){
    iv one,c,L,pi,euler,root2;iv_init(&one);iv_init(&c);iv_init(&L);iv_init(&pi);iv_init(&euler);iv_init(&root2);iv_set_si(&one,1);iv_set_si(&c,5);iv_log(&L,&c);iv_const_pi(&pi);iv_const_euler(&euler);iv two;iv_init(&two);iv_set_si(&two,2);iv_sqrt(&root2,&two);
    iv psiq;iv_init(&psiq); /* psi(1/4)=-gamma-pi/2-3log2 */
    iv halfpi,log2,three_log2,tmp;iv_init(&halfpi);iv_init(&log2);iv_init(&three_log2);iv_init(&tmp);iv_div(&halfpi,&pi,&two);iv_log(&log2,&two);iv_scale_si(&three_log2,&log2,3);iv_add(&tmp,&euler,&halfpi);iv_add(&tmp,&tmp,&three_log2);iv_neg(&psiq,&tmp);
    iv S[2],CC[2],XC[2];for(int i=0;i<2;i++){iv_init(&S[i]);iv_init(&CC[i]);iv_init(&XC[i]);}iv_set_si(&S[0],0);iv_set_si(&CC[0],0);
    for(int n=0;n<=1;n++){
        iv gs,gcc,gx1,gx2;iv_init(&gs);iv_init(&gcc);iv_init(&gx1);iv_init(&gx2);geometric_sums(n,&L,&gs,&gcc,&gx1,&gx2);
        iv zr,zi;iv_init(&zr);iv_init(&zi);iv_set_frac(&zr,1,4);iv_div(&zi,&pi,&L);civ psi,psi1;civ_init(&psi);civ_init(&psi1);digamma_and_trigamma(&psi,&psi1,&zr,&zi);
        if(n==0){ /* recompute real z=1/4 trigamma; imag zero */
            iv_set_si(&zi,0);digamma_and_trigamma(&psi,&psi1,&zr,&zi);
            iv_set_si(&S[n],0);iv_set_si(&CC[n],0);
        } else {
            iv_div(&S[n],&psi.im,&two);iv w;iv_init(&w);iv_scale_si(&w,&pi,2);iv_div(&w,&w,&L);iv_mul(&tmp,&w,&gs);iv_sub(&S[n],&S[n],&tmp);iv_clear(&w);
            iv_sub(&CC[n],&psi.re,&psiq);iv_scale_si(&CC[n],&CC[n],-1);iv_div(&CC[n],&CC[n],&two);iv_add(&CC[n],&CC[n],&gcc);
        }
        /* XC=psi1.real/4-L*gx1-gx2 */
        iv four;iv_init(&four);iv_set_si(&four,4);iv_div(&XC[n],&psi1.re,&four);iv_mul(&tmp,&L,&gx1);iv_sub(&XC[n],&XC[n],&tmp);iv_sub(&XC[n],&XC[n],&gx2);iv_clear(&four);
        civ_clear(&psi);civ_clear(&psi1);iv_clear(&zr);iv_clear(&zi);iv_clear(&gs);iv_clear(&gcc);iv_clear(&gx1);iv_clear(&gx2);
    }
    /* build 3x3 pieces */
    iv M02[3][3],MR[3][3],MP[3][3];for(int i=0;i<3;i++)for(int j=0;j<3;j++){iv_init(&M02[i][j]);iv_init(&MR[i][j]);iv_init(&MP[i][j]);}
    int nodes[3]={-1,0,1};iv L2,pi2,sixteen_pi2,pref,sinhq,eL,kappa,U,J;iv_init(&L2);iv_init(&pi2);iv_init(&sixteen_pi2);iv_init(&pref);iv_init(&sinhq);iv_init(&eL);iv_init(&kappa);iv_init(&U);iv_init(&J);iv_mul(&L2,&L,&L);iv_mul(&pi2,&pi,&pi);iv_scale_si(&sixteen_pi2,&pi2,16);iv four;iv_init(&four);iv_set_si(&four,4);iv_div(&tmp,&L,&four);iv_sinh(&sinhq,&tmp);iv_mul(&pref,&sinhq,&sinhq);iv_mul(&pref,&pref,&L);iv_scale_si(&pref,&pref,32);iv_exp(&eL,&L);
    iv num,den,a1,a2;iv_init(&num);iv_init(&den);iv_init(&a1);iv_init(&a2);iv_sub(&num,&eL,&one);iv_add(&den,&eL,&one);iv_div(&num,&num,&den);iv_mul(&num,&num,&pi);iv_scale_si(&num,&num,4);iv_log(&kappa,&num);iv_add(&kappa,&kappa,&euler);iv_div(&tmp,&L,&two);iv_exp(&U,&tmp);iv_add(&num,&U,&one);iv_log(&num,&num);iv_scale_si(&num,&num,-2);iv_mul(&den,&U,&U);iv_add(&den,&den,&one);iv_log(&den,&den);iv_add(&J,&num,&den);iv_atan(&tmp,&U);iv_scale_si(&tmp,&tmp,2);iv_add(&J,&J,&tmp);iv_add(&J,&J,&log2);iv_sub(&J,&J,&halfpi);
    int qs[4]={2,3,4,5},ps[4]={2,3,2,5};
    for(int ii=0;ii<3;ii++)for(int jj=ii;jj<3;jj++){
        int n=nodes[ii],m=nodes[jj];iv mn,numer,dm,dn;iv_init(&mn);iv_init(&numer);iv_init(&dm);iv_init(&dn);iv_set_si(&mn,m*n);iv_mul(&numer,&sixteen_pi2,&mn);iv_sub(&numer,&L2,&numer);iv mm,nn;iv_init(&mm);iv_init(&nn);iv_set_si(&mm,m*m);iv_set_si(&nn,n*n);iv_mul(&dm,&sixteen_pi2,&mm);iv_add(&dm,&dm,&L2);iv_mul(&dn,&sixteen_pi2,&nn);iv_add(&dn,&dn,&L2);iv_mul(&den,&dm,&dn);iv_mul(&num,&pref,&numer);iv_div(&M02[ii][jj],&num,&den);
        if(n==m){iv_set(&MR[ii][jj],&kappa);iv scalecc;iv_init(&scalecc);iv_scale_si(&scalecc,&CC[abs(n)],2);iv_add(&MR[ii][jj],&MR[ii][jj],&scalecc);iv_add(&MR[ii][jj],&MR[ii][jj],&J);iv_mul(&tmp,&two,&XC[abs(n)]);iv_div(&tmp,&tmp,&L);iv_sub(&MR[ii][jj],&MR[ii][jj],&tmp);iv_clear(&scalecc);} else {iv sm,sn;iv_init(&sm);iv_init(&sn);iv_set(&sm,&S[abs(m)]);if(m<0)iv_neg(&sm,&sm);iv_set(&sn,&S[abs(n)]);if(n<0)iv_neg(&sn,&sn);iv_sub(&num,&sm,&sn);iv_set_si(&den,n-m);iv_mul(&den,&den,&pi);iv_div(&MR[ii][jj],&num,&den);iv_clear(&sm);iv_clear(&sn);}
        iv_set_si(&MP[ii][jj],0);
        for(int qidx=0;qidx<4;qidx++){iv iq,ip,y,lp,sq,weight,kern,argm,argn;iv_init(&iq);iv_init(&ip);iv_init(&y);iv_init(&lp);iv_init(&sq);iv_init(&weight);iv_init(&kern);iv_init(&argm);iv_init(&argn);iv_set_si(&iq,qs[qidx]);iv_set_si(&ip,ps[qidx]);iv_log(&y,&iq);iv_log(&lp,&ip);iv_sqrt(&sq,&iq);iv_div(&weight,&lp,&sq);if(n==m){iv_div(&tmp,&y,&L);iv_sub(&tmp,&one,&tmp);iv_scale_si(&tmp,&tmp,2);iv_mul(&argn,&pi,&y);iv_scale_si(&argn,&argn,2*n);iv_div(&argn,&argn,&L);iv_cos(&kern,&argn);iv_mul(&kern,&kern,&tmp);}else{iv_mul(&argm,&pi,&y);iv_scale_si(&argm,&argm,2*m);iv_div(&argm,&argm,&L);iv_sin(&argm,&argm);iv_mul(&argn,&pi,&y);iv_scale_si(&argn,&argn,2*n);iv_div(&argn,&argn,&L);iv_sin(&argn,&argn);iv_sub(&kern,&argm,&argn);iv_set_si(&den,n-m);iv_mul(&den,&den,&pi);iv_div(&kern,&kern,&den);}iv_mul(&kern,&kern,&weight);iv_add(&MP[ii][jj],&MP[ii][jj],&kern);iv_clear(&iq);iv_clear(&ip);iv_clear(&y);iv_clear(&lp);iv_clear(&sq);iv_clear(&weight);iv_clear(&kern);iv_clear(&argm);iv_clear(&argn);}
        iv_set(&M02[jj][ii],&M02[ii][jj]);iv_set(&MR[jj][ii],&MR[ii][jj]);iv_set(&MP[jj][ii],&MP[ii][jj]);iv_clear(&mn);iv_clear(&numer);iv_clear(&dm);iv_clear(&dn);iv_clear(&mm);iv_clear(&nn);
    }
    /* even matrices */
    iv P[2][2],E[2][2],A[2][2];for(int i=0;i<2;i++)for(int j=0;j<2;j++){iv_init(&P[i][j]);iv_init(&E[i][j]);iv_init(&A[i][j]);}
    iv (*parts[2])[3]= {M02,MR}; (void)parts;
    /* helper manually: P=M02-MR; E=-MP */
    iv Fp[3][3],Fe[3][3];for(int i=0;i<3;i++)for(int j=0;j<3;j++){iv_init(&Fp[i][j]);iv_init(&Fe[i][j]);iv_sub(&Fp[i][j],&M02[i][j],&MR[i][j]);iv_neg(&Fe[i][j],&MP[i][j]);}
    for(int part=0;part<2;part++){iv (*F)[3]=part==0?Fp:Fe;iv (*O)[2]=part==0?P:E;iv_set(&O[0][0],&F[1][1]);iv_add(&tmp,&F[1][0],&F[1][2]);iv_div(&O[0][1],&tmp,&root2);iv_add(&tmp,&F[0][1],&F[2][1]);iv_div(&O[1][0],&tmp,&root2);iv_add(&tmp,&F[0][0],&F[0][2]);iv_add(&tmp,&tmp,&F[2][0]);iv_add(&tmp,&tmp,&F[2][2]);iv_div(&O[1][1],&tmp,&two);}
    for(int i=0;i<2;i++)for(int j=0;j<2;j++)iv_add(&A[i][j],&P[i][j],&E[i][j]);
    iv r[2],wvec[2];for(int i=0;i<2;i++){iv_init(&r[i]);iv_init(&wvec[i]);}iv_set_str(&r[0],"170141183460469231731687303715884105728");iv_set_str(&r[1],"-116689468362578147411353556252846438487");iv_neg(&wvec[0],&r[1]);iv_set(&wvec[1],&r[0]);
    iv GW,GE,PW,EW,BW,Cc,Z,resid,h,mval,penalty,D,pivot,schur,z2,hGE,corr;iv_init(&GW);iv_init(&GE);iv_init(&PW);iv_init(&EW);iv_init(&BW);iv_init(&Cc);iv_init(&Z);iv_init(&resid);iv_init(&h);iv_init(&mval);iv_init(&penalty);iv_init(&D);iv_init(&pivot);iv_init(&schur);iv_init(&z2);iv_init(&hGE);iv_init(&corr);iv_set_si(&GW,0);iv_set_si(&GE,0);for(int i=0;i<2;i++){iv_mul(&tmp,&wvec[i],&wvec[i]);iv_add(&GW,&GW,&tmp);iv_mul(&tmp,&r[i],&r[i]);iv_add(&GE,&GE,&tmp);}mat_quad(&PW,P,wvec,wvec);mat_quad(&EW,E,wvec,wvec);iv_add(&BW,&PW,&EW);mat_quad(&Cc,A,r,r);mat_quad(&Z,A,r,wvec);iv_set(&resid,&Z);iv_set_frac(&h,1,100000);iv_set_frac(&mval,1,4);iv_square(&z2,&Z);iv_mul(&hGE,&h,&GE);iv_div(&penalty,&z2,&hGE);iv_sub(&D,&BW,&penalty);iv_mul(&tmp,&mval,&GW);iv_sub(&pivot,&D,&tmp);iv_mul(&tmp,&Cc,&GW);iv_div(&corr,&z2,&tmp);iv_div(&schur,&BW,&GW);iv_sub(&schur,&schur,&corr);
    iv cmoat,Dnorm,pivnorm,Cnorm,Znorm;iv_init(&cmoat);iv_init(&Dnorm);iv_init(&pivnorm);iv_init(&Cnorm);iv_init(&Znorm);iv_mul(&tmp,&h,&GE);iv_sub(&cmoat,&Cc,&tmp);iv_div(&Dnorm,&D,&GW);iv_div(&pivnorm,&pivot,&GW);iv_div(&Cnorm,&Cc,&GE);iv_div(&Znorm,&Z,&GW);
    if(!iv_lower_positive(&cmoat))die("coercivity h gate failed");if(!iv_lower_positive(&pivot))die("direct LDL pivot failed");
    printf("{\n\"schema\":\"riemann.x18505.real-d0001-direct-block.v1\",\n\"support\":{\"c\":5,\"N\":1,\"sector\":\"even\",\"prime_powers\":[2,3,4,5],\"prime_power_count\":4,\"L\":");print_iv(&L);printf("},\n");
    printf("\"provenance\":{\"immutable_arb_commit\":\"34d8391395d1e08ae986bf5c1c10439f90f9cb57\",\"immutable_arb_blob\":\"85bec1e106ba4a0b2cdabb363e0fcb0dc5bdc7b2\",\"backend\":\"MPFR directed rectangles plus explicit digamma/trigamma tails\",\"precision_bits\":%d,\"psi_terms\":%d},\n",PREC,PSI_N);
    printf("\"declared_metric\":{\"coordinates\":\"[e0,(e-1+e1)/sqrt(2)]\",\"Q_W\":{\"integer_column\":[\"116689468362578147411353556252846438487\",\"170141183460469231731687303715884105728\"],\"meaning\":\"inclusion W->even D-0001 coordinates\"},\"Q_E\":{\"integer_column\":[\"170141183460469231731687303715884105728\",\"-116689468362578147411353556252846438487\"],\"meaning\":\"declared one-dimensional positive sector\"},\"G_W\":");print_iv(&GW);printf(",\"G_E\":");print_iv(&GE);printf(",\"M\":");print_iv(&GE);printf(",\"h\":{\"numerator\":1,\"denominator\":100000}},\n");
    printf("\"primitive_matrices\":{\"P_even\":[[");print_iv(&P[0][0]);printf(",");print_iv(&P[0][1]);printf("],[");print_iv(&P[1][0]);printf(",");print_iv(&P[1][1]);printf("]],\"E_even\":[[");print_iv(&E[0][0]);printf(",");print_iv(&E[0][1]);printf("],[");print_iv(&E[1][0]);printf(",");print_iv(&E[1][1]);printf("]],\"Q_even\":[[");print_iv(&A[0][0]);printf(",");print_iv(&A[0][1]);printf("],[");print_iv(&A[1][0]);printf(",");print_iv(&A[1][1]);printf("]]},\n");
    printf("\"compressed\":{\"P_W\":");print_iv(&PW);printf(",\"E_W\":");print_iv(&EW);printf(",\"B_W\":");print_iv(&BW);printf(",\"Z_W\":");print_iv(&Z);printf(",\"C\":");print_iv(&Cc);printf(",\"X_N\":{\"lower\":{\"mantissa\":\"0\",\"exponent\":0},\"upper\":{\"mantissa\":\"0\",\"exponent\":0}},\"R_N\":");print_iv(&resid);printf(",\"residual_penalty\":");print_iv(&penalty);printf(",\"D_N\":");print_iv(&D);printf(",\"D_N_normalized\":");print_iv(&Dnorm);printf(",\"C_normalized\":");print_iv(&Cnorm);printf(",\"Z_normalized\":");print_iv(&Znorm);printf(",\"m\":{\"numerator\":1,\"denominator\":4},\"LDL_pivot_D_minus_mG\":");print_iv(&pivot);printf(",\"LDL_pivot_normalized\":");print_iv(&pivnorm);printf(",\"coercivity_pivot_C_minus_hM\":");print_iv(&cmoat);printf(",\"exact_schur_normalized\":");print_iv(&schur);printf("},\n");
    printf("\"verdict\":\"CERTIFIED_POSITIVE_REAL_D0001_DIRECT_BLOCK\",\n\"delta_operator_norm_upper\":{\"mantissa\":\"0\",\"exponent\":0},\n\"scope\":\"Actual cutoff-free D-0001 c=5,N=1 even block. This is a real finite calibration packet, not the complete augmented Suzuki low hierarchy.\"\n}\n");
    return 0;
}
