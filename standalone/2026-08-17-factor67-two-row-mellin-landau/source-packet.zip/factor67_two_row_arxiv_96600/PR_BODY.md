## Standalone arXiv-style proof proposal

This add-only successor turns the finite factor-67 two-row route into a single standalone manuscript and uses the paper itself as a hostile reconstruction pass.

```text
base PR:     #555
base SHA:    341697b4694ba7f44f2ba2be73cb3fc982939412
head branch: paper/arxiv-factor67-two-row-mellin-landau-v1
```

**RH is not treated as established. This is a complete unconditional proof candidate pending hostile independent reconstruction.**

## Controlling chain

```text
positive parity-labelled native source
 -> exact nonduplicating causal identity
 -> finite first-owner paired stopping line
 -> directed compact-plus-MPFR terminal Hall realization
 -> c_X(2), c_X(3) >= 0
 -> two reciprocal-zeta Mellin transforms
 -> exact two-row common-zero exclusion
 -> Landau
 -> RH candidate.
```

## Hardening decisions

The paper permanently rejects:

- fixed-product cross-knot convexity;
- unrestricted rough-reservoir comparison;
- branchwise positive observation of an oriented child;
- native endpoint benchmark closure.

The complete LaTeX source, deterministic PDF, theorem ledger, frozen import lock, checker, and hostile review specification are included.

```text
PASS_ARXIV_FACTOR67_TWO_ROW_RECONSTRUCTION_ALGEBRA
proof object: 8593c3a48270c49fff3e05034e5896aba77443b48b7eb002b1e1b3f978c0d895
```

The replay explicitly records that it does not prove the stopping theorem, terminal AVLT theorem, or RH.
