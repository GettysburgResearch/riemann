#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then echo "usage: $0 /path/to/riemann" >&2; exit 2; fi
repo="$(cd "$1" && pwd)"
packet="$(cd "$(dirname "$0")" && pwd)"
base="341697b4694ba7f44f2ba2be73cb3fc982939412"
branch="paper/arxiv-factor67-two-row-mellin-landau-v1"
cd "$repo"
test "$(git rev-parse HEAD)" = "$base" || { echo "expected base $base" >&2; exit 1; }
test -z "$(git status --porcelain)" || { echo "working tree is not clean" >&2; exit 1; }
python3 "$packet/validate_packet.py"
git switch -c "$branch"
git apply --index "$packet/t96600-add-only.patch"
python3 experiments/X-96600-paper-reconstruction/verify.py --output /tmp/t96600-verification.json
cmp /tmp/t96600-verification.json experiments/X-96600-paper-reconstruction/results/verification.json
git commit -m "paper: finite factor-67 two-row Mellin-Landau proposal"
git push -u origin "$branch"
if command -v gh >/dev/null 2>&1; then
  gh pr create --draft --base research/gpt56-pro/96500-finite-factor67-two-row-landau \
    --head "$branch" \
    --title "paper: finite factor-67 two-row Mellin-Landau RH proposal" \
    --body-file "$packet/PR_BODY.md"
else
  echo "branch pushed; gh unavailable, PR not opened" >&2
fi
