#!/usr/bin/env python3
from pathlib import Path
import hashlib, subprocess
root=Path(__file__).resolve().parent
for line in (root/'PAPER_96600_SHA256SUMS').read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    want,rel=line.split('  ',1)
    got=hashlib.sha256((root/rel).read_bytes()).hexdigest()
    if got!=want: raise SystemExit(f'hash mismatch: {rel}')
tmp=root/'.verification.tmp.json'
try:
    subprocess.run(['python3',str(root/'experiments/X-96600-paper-reconstruction/verify.py'),'--output',str(tmp)],check=True)
    retained=root/'experiments/X-96600-paper-reconstruction/results/verification.json'
    if tmp.read_bytes()!=retained.read_bytes(): raise SystemExit('checker result mismatch')
finally:
    tmp.unlink(missing_ok=True)
print('PASS_DETERMINISTIC_ARXIV_FACTOR67_TWO_ROW_PACKET')
